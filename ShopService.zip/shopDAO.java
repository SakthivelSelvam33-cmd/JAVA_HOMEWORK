

package shop;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class shopDAO 
{
    public Connection connectdb() throws ClassNotFoundException, SQLException
    {
        Class.forName("org.postgresql.Driver");
        String url="jdbc:postgresql://localhost:5432/Sbi_db";
        String user="postgres";
        String pass="8992";
        Connection con=DriverManager.getConnection(url,user,pass);
        Statement stmt=con.createStatement();
        String query="create table customer(cust_id int primary key,cust_name varchar(50),city varchar(20),grade int not null,salesman_id int not null);";
        stmt.executeUpdate(query);
        return con;
    }
    public int createcustomer(ShopModel sm ) throws ClassNotFoundException, SQLException
    {
        
        Connection con=connectdb();
        
        String query="insert into Customer values(?,?,?,?,?)";
        PreparedStatement ps=con.prepareStatement(query);
        ps.setInt(1, sm.getCust_id());
        ps.setString(2, sm.getCust_name());
        ps.setString(3, sm.getCity());
        ps.setInt(4, sm.getGrade());
        ps.setInt(5, sm.getSalesman_id());
        
        int res=ps.executeUpdate();
        return res;
    }
    //int cust_id,String cust_name,String city,int grade,int salesman_id) throws ClassNotFoundException, SQLException
    
}
