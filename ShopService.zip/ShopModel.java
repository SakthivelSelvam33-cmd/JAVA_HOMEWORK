
package shop;


public class ShopModel 
{
    private int cust_id;
    private String cust_name;
    private String city;
    private int grade;
    private int salesman_id;

    public ShopModel() {
    }

    public ShopModel(int cust_id, String cust_name, String city, int grade, int salesman_id) {
        this.cust_id = cust_id;
        this.cust_name = cust_name;
        this.city = city;
        this.grade = grade;
        this.salesman_id = salesman_id;
    }

    public int getCust_id() {
        return cust_id;
    }

    public void setCust_id(int cust_id) {
        this.cust_id = cust_id;
    }

    public String getCust_name() {
        return cust_name;
    }

    public void setCust_name(String cust_name) {
        this.cust_name = cust_name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public int getSalesman_id() {
        return salesman_id;
    }

    public void setSalesman_id(int salesman_id) {
        this.salesman_id = salesman_id;
    }
  
}
