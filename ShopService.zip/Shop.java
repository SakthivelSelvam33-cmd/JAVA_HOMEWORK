
package shop;

import java.sql.SQLException;
import java.util.Scanner;


public class Shop {

    
    public static void main(String[] args) throws ClassNotFoundException, SQLException 
    {
        Scanner sc=new Scanner(System.in);
        Scanner sc1=new Scanner(System.in);
        ShopModel sm=new ShopModel();
        shopDAO s1=new shopDAO();
       s1.createcustomer(sm);
        int choice;
        do
        {
            System.out.println("MENU");
            System.out.println("1.Insert");
            System.out.println("2.Exit");
            System.out.println("Enter the choice");
            choice=sc.nextInt();
            
            switch(choice)
            {
                case 1:
                    System.out.println("cust_id");
                    int cust_id=sc.nextInt();
                    System.out.println("cust_name");
                    String cust_name=sc1.nextLine();
                    System.out.println("city");
                    String city=sc1.nextLine();
                    System.out.println("grade");
                    int grade=sc.nextInt();
                    System.out.println("Salesman_id");
                    int salesman_id=sc.nextInt();
                    s1.createcustomer(sm);
                    break;
            }
        }while(choice!=2);
        }
}
       
    
    

