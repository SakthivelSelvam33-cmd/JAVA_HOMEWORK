

package shop;

import java.sql.SQLException;


public class ShopService 
{
    public void insertdata(ShopModel sm) throws ClassNotFoundException, SQLException
    {
        shopDAO s1=new shopDAO();
        int res=s1.createcustomer(sm);
    
        if(res>0)
        {
            System.out.println("Data inserted");
        }
        else
        {
            System.out.println("data not inserted");
        }
    }
    
}
