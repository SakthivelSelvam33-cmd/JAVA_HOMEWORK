
package gymapplication;


public interface GymRules 
{
    int calculatefee(int month);
    
}
